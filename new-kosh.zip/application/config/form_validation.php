<?php
	$config['error_prefix'] = '<div class="error_prefix text-right">';
	$config['error_suffix'] = '</div>';