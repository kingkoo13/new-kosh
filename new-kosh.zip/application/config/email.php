<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['protocol']         = 'smtp'; // 'mail', 'sendmail', or 'smtp'
$config['mailpath']         = '/usr/sbin/sendmail';
$config['smtp_host']        = 'smtp.gmail.com'; // if you are using gmail
$config['smtp_user']        = 'sheryarahmed@gmail.com';
$config['smtp_pass']        = 'LovefisT911'; // App specific password
$config['smtp_port']        = 465; // for gmail
$config['smtp_timeout']     = 5;  